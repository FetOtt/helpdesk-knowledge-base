# Windows Commands Cheat Sheet (Helpdesk Focus)

## Network & IP

```powershell
ipconfig          # Basic IP info
ipconfig /all     # Detailed IP info
ipconfig /release # Drop IP
ipconfig /renew   # Request new IP
ping 8.8.8.8      # Test internet
ping google.com   # Test DNS + internet
tracert google.com # Trace route to site
nslookup google.com # DNS lookup
```

## System & Performance

```powershell
taskmgr          # Open Task Manager
tasklist         # List running processes
sfc /scannow     # Check system files
chkdsk C: /f     # Check disk for errors
```

## User & System Info

```powershell
whoami           # Show current user
hostname         # Show computer name
systeminfo       # System details
```

## Logs & Tools

```powershell
eventvwr         # Event Viewer
```
