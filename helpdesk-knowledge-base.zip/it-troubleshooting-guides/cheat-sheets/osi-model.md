# OSI Model Cheat Sheet

## Layers (Top → Bottom)

7. **Application** – Apps & protocols (HTTP, HTTPS, DNS, SMTP)  
6. **Presentation** – Encryption, compression (SSL/TLS)  
5. **Session** – Starts/ends sessions  
4. **Transport** – TCP/UDP, ports, reliability  
3. **Network** – IP addresses, routing, subnets  
2. **Data Link** – MAC addresses, frames, switching  
1. **Physical** – Cables, Wi-Fi, signals, connectors  

## Memory Tricks

- 7 → 1: **All People Seem To Need Data Processing**  
- 1 → 7: **Please Do Not Throw Sausage Pizza Away**

## Troubleshooting by Layer

- Layer 1: Cables, Wi-Fi, power  
- Layer 2: Switch, MAC table, VLAN  
- Layer 3: IP, gateway, routing  
- Layer 4: Ports, TCP/UDP  
- Layer 7: App-specific issues
