# Helpdesk Troubleshooting Flow

1. **Gather Information**
   - What are you trying to do?
   - What changed recently?
   - Is anyone else affected?

2. **Check the Basics**
   - Power, cables, Wi-Fi, restart device

3. **Identify the Layer**
   - Physical (Layer 1)?
   - Network (Layer 3)?
   - Application (Layer 7)?

4. **Test & Narrow Down**
   - Use `ping`, `ipconfig`, Task Manager, etc.
   - Try another device if possible

5. **Apply Fix**
   - Change setting, update driver, restart service, etc.

6. **Verify With the User**
   - Ask user to test their original task

7. **Document**
   - Issue summary
   - Root cause
   - Fix
   - Any follow-up
