# Wi-Fi Standards Cheat Sheet

| Standard  | Band     | Max Speed (theoretical) | Common Name   |
|-----------|----------|-------------------------|---------------|
| 802.11b   | 2.4 GHz  | 11 Mbps                 | Legacy        |
| 802.11g   | 2.4 GHz  | 54 Mbps                 | Legacy        |
| 802.11n   | 2.4/5 GHz| ~600 Mbps               | Wi-Fi 4       |
| 802.11ac  | 5 GHz    | >1 Gbps                 | Wi-Fi 5       |
| 802.11ax  | 2.4/5/6  | >10 Gbps                | Wi-Fi 6/6E    |

Quick notes:

- 2.4 GHz = longer range, more interference  
- 5 GHz = faster, shorter range  
- Wi-Fi 6/6E = modern, dense environments
