# Binary to Decimal Cheat Sheet

## 8-Bit Values

From left (most significant) to right:

| Bit Position | Value |
|--------------|-------|
| 1            | 128   |
| 2            | 64    |
| 3            | 32    |
| 4            | 16    |
| 5            | 8     |
| 6            | 4     |
| 7            | 2     |
| 8            | 1     |

Pattern: **1, 2, 4, 8, 16, 32, 64, 128** (each doubles).

## Common Last-Octet Masks

| Binary     | Decimal | CIDR |
|------------|---------|------|
| 10000000   | 128     | /25  |
| 11000000   | 192     | /26  |
| 11100000   | 224     | /27  |
| 11110000   | 240     | /28  |
| 11111000   | 248     | /29  |
| 11111100   | 252     | /30  |

Practice: Add the values where bits are 1 to get the decimal.
