# Basic Network Troubleshooting

## Quick Layer Checklist
- **Layer 1 (Physical):** Cables, Wi-Fi status, link lights
- **Layer 2 (Data Link):** Switch ports, MAC, VLANs
- **Layer 3 (Network):** IP, subnet, gateway, routing

## Core Commands

### View IP Information
```powershell
ipconfig /all
```

### Test Internet Connectivity
```powershell
ping 8.8.8.8
```

### Test DNS Resolution
```powershell
ping google.com
```

### Trace Route to a Site
```powershell
tracert google.com
```

## Common Issues
- Wrong default gateway
- DNS set incorrectly
- DHCP not assigning IP (169.x.x.x)
- User on wrong VLAN or Wi-Fi SSID

## Documentation
Always note:
- User’s device name
- IP info (IP, gateway, DNS)
- What worked / failed in tests
- Root cause and fix
