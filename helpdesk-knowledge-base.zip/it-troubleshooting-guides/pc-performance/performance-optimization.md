# PC Performance Optimization Guide

## 1. Identify Symptoms
- Slow applications?
- High CPU or memory?
- Long boot times?
- Programs freezing or crashing?

## 2. Task Manager Review
- Open Task Manager (`Ctrl + Shift + Esc`)
- Check which apps use the most CPU, memory, or disk
- End clearly unnecessary tasks (with caution)

## 3. Startup Optimization
- In Task Manager → Startup tab
- Disable non-essential startup apps

## 4. Cleanup
- Run Disk Cleanup
- Delete temporary files
- Clear browser cache and history

## 5. Malware Check
- Run Windows Defender or other AV scan
- Remove detected threats

## 6. Hardware Checks
- Check free disk space
- Check RAM usage patterns
- Listen for strange drive/fan noises

## 7. Document
- Initial complaint
- Changes made
- Final performance result
