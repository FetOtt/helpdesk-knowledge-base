# Printer Troubleshooting Guide

## 1. Identify the Issue
- Local or network printer?
- Error messages?
- When did it last work?

## 2. Hardware Checks
- Power on?
- Paper loaded?
- Toner/ink levels OK?
- Cables connected? (USB, network, power)

## 3. OS-Level Checks
- Is this the default printer?
- Clear the print queue
- Restart Print Spooler service

## 4. Network Checks (for network printers)
- Ping the printer IP
- Verify printer is online
- Re-map shared printer
- Confirm correct port in printer properties

## 5. Driver & Permissions
- Update or reinstall printer driver
- Confirm user has permission to print

## 6. Document
- User’s original complaint
- Root cause
- Fix applied
- Any follow-up steps
