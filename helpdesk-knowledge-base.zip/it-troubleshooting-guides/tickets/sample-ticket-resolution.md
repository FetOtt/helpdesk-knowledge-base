# Sample Ticket Resolution

**Ticket ID:** SAMPLE-001  
**Issue:** User unable to access shared drive X.

## Environment
- Windows 10 client
- User in DEPT-ACCT
- File server: FS-01

## Troubleshooting Steps
1. Verified user could access other network resources ✔
2. Confirmed network connectivity with `ping FS-01` ✔
3. Checked mapped drives – drive X disconnected ❌
4. Attempted manual connection to `\\FS-01\ShareX` – Access denied ❌
5. Checked user’s group membership in AD – missing from `ShareX_Read` group ❌
6. Added user to `ShareX_Read` group ✔
7. Asked user to log off and log back in ✔
8. Verified user could now access drive X ✔

## Root Cause
User not in the correct Active Directory security group after a department change.

## Resolution
- Updated user’s group membership
- Confirmed access with the user
- Documented the change in ticketing system

## Prevention
- Review onboarding/offboarding checklist for group membership updates
