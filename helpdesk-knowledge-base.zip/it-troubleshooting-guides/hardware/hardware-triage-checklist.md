# Hardware Triage Checklist

## 1. Power Checks
- Is the device plugged in?
- Power strip or UPS switched on?
- Power brick warm or cold?

## 2. External Inspection
- Any visible damage?
- Loose ports or connectors?
- Fan vents blocked by dust?

## 3. Internal Checks (if safe/allowed)
- Reseat RAM modules
- Check cable connections to motherboard and drives
- Ensure fans spin freely

## 4. Boot Issues
- Does BIOS/UEFI screen appear?
- Any POST beeps or error lights?
- Try booting from a known-good USB or recovery media

## 5. Storage
- Confirm drives are detected in BIOS/UEFI
- Check HDD/SSD health with tools (if OS boots)

## 6. Documentation
- Device ID / asset tag
- Symptoms
- Troubleshooting steps taken
- Final diagnosis and next action (repair, replace, escalate)
